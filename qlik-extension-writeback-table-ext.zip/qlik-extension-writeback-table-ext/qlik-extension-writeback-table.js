define(['./dist/qlik-extension-writeback-table'], (supernova) => supernova);
